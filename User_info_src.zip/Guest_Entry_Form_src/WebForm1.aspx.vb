Imports System.Xml
Imports System.Xml.XmlDocument

Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents ButtonContinue As System.Web.UI.WebControls.Button
    Protected WithEvents TextBoxName As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBoxEMail As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBoxLocation As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBoxComments As System.Web.UI.WebControls.TextBox
    Protected WithEvents CheckBoxPrivate As System.Web.UI.WebControls.CheckBox
    Protected WithEvents TextBoxHomepageURL As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub ButtonContinue_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonContinue.Click
        'load guetbook XML database
        Dim xdoc As New XmlDocument
        xdoc.Load(Server.MapPath("guestbook.xml"))
        'get status of private
        Dim prev As String
        If (CheckBoxPrivate.Checked) Then
            prev = "yes"
        Else
            prev = "no"
        End If
        'create a new element 
        Dim elem As XmlElement
        elem = xdoc.CreateElement("guest")
        elem.SetAttribute("private", prev)
        'add the new guest as the first node
        xdoc.DocumentElement.PrependChild(elem)
        'add others
        addTextElement(xdoc, elem, "name", TextBoxName.Text)
        addTextElement(xdoc, elem, "email", TextBoxEMail.Text)

        Dim newatt As XmlAttribute
        newatt = xdoc.CreateAttribute("url")
        newatt.Value = TextBoxHomepageURL.Text
        elem.LastChild.Attributes.Append(newatt)

        addTextElement(xdoc, elem, "location", TextBoxLocation.Text)
        addTextElement(xdoc, elem, "comment", TextBoxComments.Text)
        'write date field now
        Dim strDate As String
        strDate = DateTime.Now.ToLongDateString() + " - " + DateTime.Now.ToLongTimeString()
        addTextElement(xdoc, elem, "date", strDate)
        xdoc.Save(Server.MapPath("guestbook.xml"))
        Response.Redirect("view.aspx")
    End Sub

    Private Sub addTextElement(ByVal doc1 As XmlDocument, ByVal elem1 As XmlElement, ByRef strTag As String, ByRef strVal As String)
        Dim nodeElem = doc1.CreateElement(strTag)
        Dim nodeText = doc1.CreateTextNode(strVal)
        elem1.AppendChild(nodeElem)
        nodeElem.AppendChild(nodeText)
    End Sub

End Class
